# NovaStream

Live streaming where every viewer matters. Rooms stay human-sized, and the first viewers in are guaranteed to be heard.
Runs on **PC (any browser, installable)** and **Android (installable web app, or a native APK you build)**.

**Status: Phases 1 and 2 complete, plus the admin area and the safety fixes from the promises audit.** **Chat Replay** is built (see below). The rest of Phase 3 (money, clips, video recordings) is on the roadmap below. Read `docs/PROMISES_AUDIT.md` for the full list of what the app used to promise but not deliver, and how each item is fixed.

## Admin area and safety

**Becoming an admin.** Put your username in `ADMIN_USERNAMES` in `.env`, restart, and register that account straight away (whoever registers that name first becomes the admin). Or sign up normally and run `npm run make-admin -- yourname`. Then open **Admin** in the menu.

| Tab | What it does |
|---|---|
| Overview | People, sign-ups, live streams, open reports and appeals, uptime, memory, database size, recent errors, and warnings about risky settings |
| Reports | The queue for every report (chat, posts, comments, profiles, Circles, streams). Urgent ones first. Dismiss, warn, delete the content, suspend or ban. Reporters are told the outcome |
| Users | Search accounts. Warn, suspend, ban, lift, verify, make or remove admin, clear a profile, log out everywhere, issue a password-recovery code, delete. Full history per account |
| Appeals | Approve or reject appeals from suspended and banned people, with a reply |
| Live streams | See everything live, end a stream with a reason |
| Content | Search and delete posts, comments and whole Circles |
| Word filter | Words masked across the whole site, whole-word matching |
| Site settings | Allow sign-ups, maintenance mode, announcement banner, room size, anti-bot account age, post cooldown. Changes apply instantly |
| Legal pages | Edit the Community Guidelines, Terms and Privacy Policy |
| Backups | Automatic every 24 hours (newest 7 kept), back up now, download |
| Audit log | Every admin action, who did it and when |

**For everyone:** Account settings (change password, log out of all devices, download my data, delete my account), a report dialog on messages, posts, comments, profiles, Circles and streams, appeals on the login screen, and a "Forgot your password?" page that works with an admin-issued one-time code (no email service is built in).

**Before you open it to the public:** set the anti-bot account age to 60 minutes, set `JWT_SECRET`, run HTTPS and a TURN server, have a lawyer review the legal pages, give admin accounts long unique passwords (there is no two-factor login yet), and make sure someone reads the report queue.

**Restoring a backup:** stop NovaStream, replace `data/novastream.db` with the backup file (renamed to `novastream.db`), start it again.

## Chat Replay

Every chat line of a live stream is saved with the second it was sent. When the stream ends, anyone logged in can open **Chat replay** and watch the chat scroll past in sync with a timeline, the way Twitch and YouTube replay chat on saved broadcasts.

| Where | What you get |
|---|---|
| Replay page `#/replay/<id>` | Clock, play / pause, back and forward 10 s, speed (0.5x to 8x), a draggable position slider, and a **chat activity chart** (click it to jump to a busy moment). Messages appear at the exact second they were first sent and are rebuilt correctly when you scrub. Pinned Early Bird questions are marked on the chart and listed; the three busiest moments are one-tap jumps. Clicking a message's time jumps to it. **Share at this time** copies a link such as `#/replay/12/340` that opens at 5:40. Keys: Space or K play/pause, arrows skip 5 s, J and L skip 10 s |
| Channel page | A **Chat replays** list of past streams under the About box. While live, a small note says chat is saved and for how long |
| Profile and Dashboard | Each past stream links to its chat replay |
| Live player | A **Chat overlay** button floats the newest messages over the video (useful in theatre mode and fullscreen). The choice is remembered on that device |

**How it behaves.** Chat is fetched one minute at a time and prefetched ahead, so long streams stay fast; if a minute has not loaded yet the replay waits ("Loading chat...") instead of skipping. Replays are read-only. Report and Block work on replayed messages like they do live.

**Safety and privacy.**
- Logged-in people only, like the rest of the app. People you blocked are left out of your replay.
- Messages a moderator deleted are removed from the saved log, and their text is erased.
- The site word filter and the streamer's blocked words are applied again when the replay plays, so words added later are masked in old chats too.
- Messages from suspended or banned accounts are hidden (they return if the suspension is lifted).
- The streamer can **Delete replay** on the replay page, and an admin can too (logged in the audit log).
- Deleting an account removes that person's saved messages and the replays of their own streams. **Download my data** includes the messages they sent.
- Admin, Site settings: switch Chat Replay on or off and choose how many days chat is kept (1 to 365, default 30). Older chat is deleted automatically every hour. Turning it off stops saving and hides replays.
- **Update your Privacy Policy** (Admin, Legal pages) to say that live chat is saved and for how long. The built-in text was not changed for you.

**Important limit: there is no video in the replay.** NovaStream's video is peer-to-peer and is not recorded, so a replay is the chat, pins and activity chart on a timeline. The player runs from a millisecond clock on purpose: when you add recordings (a media server, see Honest limits), point that clock at the video's `currentTime` (marked in `public/replay.js`) and the chat will sync to the video with no other changes.

## Playful look, Spotlight slideshow and search as you type

- **Post cards** are now colourful covers tinted by the author's colour, with the author, post type and time floating on top and live counts (top reactions, comments, reposts) on the bottom edge. Short posts are shown big.
- **Spotlight** at the top of the Feed is a slideshow of the most talked-about recent posts. It changes every **4 seconds**, pauses on hover, focus, touch and when the tab is hidden, has Pause/Play, arrows, clickable progress dots and swipe on phones, and starts paused for people who prefer reduced motion. Posts are text-only for now (there are no image uploads), so slides are text covers.
- **Search as you type**: the header and menu search boxes show up to 6 matching profiles after 2 letters (name starts with it first, then word match, then contains; people you follow and live creators rank higher), with the match highlighted, LIVE and Following tags, keyboard navigation (arrows, Enter, Escape) and a "See all results" row. Focusing an empty box shows your recently opened profiles, with a Clear button (stored on that device only). Same privacy rules as full search: teen accounts only appear on an exact username, and blocked or banned people never appear. API: `GET /api/suggest?q=`, login required, rate limited.
- **Copy and buttons**: headings, buttons, placeholders and empty states were rewritten to be friendlier, and buttons, chips and reactions have gradients, glow and hover motion (switched off for reduced motion).

## Formal look, pictures and videos in posts, wider search suggestions

- **Look.** The interface was restyled to be plain and professional: solid colours, 1px rules, small corner radii, regular-weight button text in one size scale (38px, 30px for small), no gradients, glow, blur or hover motion. Titles are a light green (`--title` in `public/style.css`; a darker green in Light mode so it stays readable). The Back button is a "<" chevron. This block is the last section of `style.css` and overrides the older playful and black-and-white rules; delete it to return to the previous look.
- **Pictures and videos in posts.** The post box has a **Photo or video** button: up to 4 pictures (JPEG, PNG, WebP, GIF) or one video (MP4 or WebM, up to 20 MB). Pictures are resized in the browser to 1600px JPEG (which also removes camera location data); GIFs up to 5 MB and videos are sent as they are. The server checks the first bytes of every file, refuses anything else (including SVG), keeps files in the database table `post_media` (so backups and account deletion cover them), and serves them from `/media/<id>` with range support for video. Files that are never attached to a post are deleted after an hour. Deleting a post, a Circle, or an account (or an admin removing a post) deletes its files. API: `POST /api/media` (raw file body, login required, rate limited), then `POST /api/posts` with `media: [ids]`. A post may have pictures and no text.
- **Spotlight slideshow** now shows posted pictures (newest first, with the author and caption over the picture) and fills up with popular text posts when there are fewer than two pictures. It still changes every 4 seconds and pauses on hover, focus, touch and when the tab is hidden.
- **Search suggestions** now appear on the header box, the menu box and the Search page, and list people, Circles and live streams as you type (`GET /api/suggest?q=`).
- **Safety note.** There is still no automatic image or video scanning. Reported posts can be removed by an admin, but before opening this to the public (especially with teen accounts) add scanning or have moderators review reports promptly. Large videos make `data/novastream.db` and its backups grow quickly.

## Black and white

The whole interface is **black and white**. Dark mode is white on black, Light mode is black on white, and there is one accent: the text colour (solid white or black buttons, outlined secondary buttons, grey for everything else). Switch under Settings, Appearance, or with the sun/moon button in the bottom dock.

- **Icons are colourless line icons** (`public/icons.js`, single-colour SVG that follows the text colour) in the dock, menu, alerts, post cards, chat badges and buttons. Emoji used as decoration in labels and buttons were removed.
- Photos you upload (profile picture, cover photo) keep their real colours. Generated avatars and colour covers are shown in greyscale.
- **Emoji reactions** are still emoji (they are the content people choose), but they are shown in greyscale.
- **Usernames in chat are plain** by default. Settings, Appearance has "Coloured usernames in chat" for people who want the old per-person colours.
- An automated check scans every element's computed colours on the profile, settings, alerts, feed and channel pages in both themes; none are coloured.

## Profile, themes, dock and chat look

- **Facebook-style profile**: a wide cover, a big round picture overlapping it, name, followers and action buttons, then tabs (Posts, About, Streams) with an Intro card beside them. The **cover can be an uploaded photo**: on your own profile use "Add cover photo" (cropped in the browser to 1200x400, max 300 KB, stored in the `banners` table, served from `/banners/<id>.jpg`; API `PUT` and `DELETE /api/profile/banner`). Without a photo the colour cover is used. A moderator's "clear profile" action also removes the cover photo, and deleting an account removes it.
- **Light and dark mode** (black and white, see above): Settings, Appearance: Light, Dark or Match my device. The default is dark. The choice is remembered on that device and applied before the page paints (`public/theme.js`). There is also a sun/moon button in the dock.
- **Bottom dock**: icons only (Browse, Feed, Circles, Search, Go live, Alerts, My profile, light/dark). It is hidden; move the pointer to the bottom edge of the screen, or tap or Tab to the little handle, and it slides up, then tucks away by itself. Icons are in `public/icons.js` (inline SVG, no external files).
- **Chat on the video** is now Twitch-style: each person can get one stable username colour from a fixed palette (an opt-in setting, off by default, also used in the chat panel and in replays), streamer and moderator badges, dark pill lines that slide in, and the block sits higher above the player controls. Turn it on with the Chat overlay button.
- **Reactions** use a more current set: ❤️ 🔥 🫶 😭 💀 🤯 😂 🎉 👏. There is no separate sticker picker yet, and brand-new emoji may show as a box on very old phones.
- **Menu and Notifications** have icon tiles, gradient highlights and colour-coded alert types.

## Accounts, profile pictures, followers and the menu

| Feature | How it works |
|---|---|
| Logged-out visitors | Can only read the **Community feed**, the legal pages and the login, sign-up and password-reset pages. Browse, channels, profiles, Circles, search, notifications, the dashboard and Go live all need an account. Opening one of those links while logged out sends the visitor to the login page and brings them back to it after they log in. This is enforced in the app screens; the public read-only API endpoints behind them are unchanged |
| Profile picture | **Edit profile → Upload photo** (PNG, JPEG, WebP or GIF, up to 10 MB). The browser crops it to a square, shrinks it to 256px and re-encodes it as a JPEG; the server accepts only a valid JPEG under 250 KB and stores it in the database (so backups and account deletion cover it). The photo shows everywhere the emoji avatar did (header, chat lists, feed, Circles, search, follower lists, stream cards). **Remove photo** goes back to the emoji. Admin **Clear profile** also removes the photo |
| Followers | The follower and following counts on every profile are links. `#/u/<name>/followers` and `#/u/<name>/following` list the people (newest first, 40 at a time) with a Follow button and a LIVE badge. Logged-in people only. Suspended or banned accounts and people blocked in either direction are left out |
| Back button | A Back button appears in the header on every page except the start page. It returns to the previous NovaStream page and falls back to the start page if there is none (for example after opening a shared link) |
| Menu | The slide-out menu (tablet and phone) has a person card with live follower and following counts, a search box, and collapsible sections (Explore, My space, Account, About) with descriptions, a live-now badge, an unread badge, the current page highlighted, and swipe-left to close. The Following and Live now lists in the sidebar (all screen sizes) collapse, show how many people are watching and have a filter box |

## Feed posts, stream chat and the blue accent

| Feature | How it works |
|---|---|
| Post cards | Laid out like Facebook: avatar, bold name, a small grey line with @username and time, a **...** menu (copy link, report or delete), full-width media, a counts row (reactions on the left, comments and reposts on the right), then a **React / Comment / Repost / Share** row. Hover (or long-press on a phone) **React** to pick an emoji. Comments show as grey bubbles with small Reply and time links and a rounded comment box with your avatar |
| Video and audio in posts | Only one video or audio plays at a time, and anything playing **pauses when you scroll past it**. Each video has a **Player** button that opens a larger media player and carries on from the same moment; closing it puts the post's video back at that spot |
| Stream chat | The message box sits at the very top of the chat, directly under the "Stream chat" heading, with your avatar beside it. On tablets and phones the whole chat now sits right under the video (before the reactions and channel info), so the box is never far down the page. Messages sent too quickly are quietly ignored (no "Slow down" alert) and your text stays in the box |
| Chat overlay on the video | Plain coloured text with no boxes, on the left of the video. New lines fly in from the **right edge of the viewer's screen** and settle in the left column, older lines are pushed up as if you were scrolling the chat, and they fade out a little way below the top of the frame. **Every line gets a new random colour** (never the same as the line before). Lines left sitting for 20 seconds slide up and fade. Reduced-motion settings turn the animation off |
| Theatre | Makes the video bigger: on wide screens the chat narrows from 360px to 300px and the video grows to fill the height of the window; on tablets and phones it just lifts the video's height limit. While it is on, the Theatre button reads **Exit theatre** and is filled blue, with a thin blue glow around the video. The Chat overlay button is filled blue while it is on too |
| Viewer count (streamer) | While you are live, a **watching** counter shows on the right of the video (the overlay is on the left). It changes the moment someone joins or leaves, including when they close their tab |
| Go live / End stream | The Go live button (header, menu and bottom dock) turns red and says **End stream** while you are live, and ends the stream when pressed. A stream still ends when the host leaves their own channel page, as before |
| Forms | Labels have 10px of space above their input and sit above the focus glow. The sign-up checkbox lines up with the first line of its text. Focused inputs glow **#005eff** |
| Accent colour | **#005eff** replaces the old green: page titles, primary buttons, the focus glow, selected tabs and chips, the React button, verified ticks, progress bars and check boxes |

## Design and screen sizes

Blue and teal on deep navy, with amber for Early Bird highlights. All colours live in the `:root` variables at the top of `public/style.css` (`--brand`, `--brand-2`, `--dawn`, `--bg`, `--panel`), so changing the look takes one edit.

| Screen | What changes |
|---|---|
| Desktop (over 1100px) | Sidebar, top tabs, full search box |
| Laptop (1000-1100px) | Search becomes an icon |
| Tablet (720-1000px) | Slide-out menu (the menu button) carries the main links, the live channels and Log out; channel page stacks video above chat |
| Phone (under 720px) | Bottom tab bar (Browse, Feed, Circles, Alerts, Profile), single-column layouts, always-visible player controls, bigger touch targets, no zoom-on-focus in forms, safe-area padding for notches and gesture bars |

Tested at 320, 375, 414, 768, 820, 900, 1024, 1280 and 1440px wide: no sideways scrolling on 13 pages, header always fits, menu and bottom bar behave, touch targets are tall enough.

## What is in Phase 2 (all tested)

| Area | What you get |
|---|---|
| Social feed | Posts (update, question, announcement), emoji reactions (one per person), comments with threaded replies, reposts, share links, report, delete; Following and Discover tabs; `@mentions` |
| Circles | Community homes with name, emoji, description, member badges (Founder, Moderator, Founding member, First contribution, Regular, Trusted), discussion feed, owner/mod announcements, scheduled events with RSVP, a member-count goal with progress bar, an "Our story" milestone history, owner-appointed Circle moderators, a LIVE badge when the creator streams |
| Notifications | Bell with live unread count and pop-ups, inbox page, per-type switches (followers, going live, mentions, comments, Circle news, events, answered pins, achievements), quiet hours that keep alerts in the inbox without pop-ups |
| Search and discovery | One search across people, live streams, Circles and posts with filters (type, category, live only); Recommended row (your interests, what you watched, who you follow), a **Rising channels** row that always shows small streams, and Circles to explore |
| Appreciation score | Transparent points and level on every profile with a "How is this calculated?" breakdown. Caps per source, no points for reacting to yourself, reactions from brand-new accounts ignored. It is never used for ranking or discovery |
| Achievements | 8 unlockable badges (first post, first comment, Early Bird, got a question answered, first stream, Circle founder, Circle member, regular poster) with notifications |
| Chat | Threaded replies, `@mentions` that notify, highlighted mentions |
| Analytics | Unique viewers, returning viewers, average watch time, retention per stream, chat messages, viewers who followed, 14-day follower growth, stream-by-stream table |

## What is in Phase 1 (all tested)

| Area | What you get |
|---|---|
| Accounts | Sign up / log in (bcrypt + JWT), 13+ age gate, teen flag |
| Profiles | Display name, bio, emoji avatar, banner, interests, follower/following counts, up to 6 links (YouTube, Twitch, TikTok, Instagram, Facebook, Kick, X, website, donation), recent streams |
| Creator channels | 14 categories, up to 5 tags, stream title and description, channel description, links hub |
| Live streaming | Camera or screen share (WebRTC), reconnect handling, small-room cap |
| Player | Volume, mute, fullscreen, theatre mode, share button, live viewer count |
| Chat | Real-time chat, rate limit, word filter, report, block user (hides their messages for you) |
| Reactions | Animated emoji reactions over the stream (never block the video) and reaction counts on chat messages |
| Moderation | Streamer appoints moderators; timeout, mute, delete message, slow mode, per-channel blocked words |
| Early Bird Pins | First 4 viewers get a bird badge and 3 pins each; streamer or a mod taps Answered; streamer/mod can switch off one viewer's pins |
| Polls | Streamer or mods run live polls; one vote per viewer |
| Creator dashboard | Followers, streams, hours, peak and average viewers, peak-viewers chart, channel settings, moderators, reports about your chat |
| Design | New NovaStream dark theme, responsive for desktop, tablet and phone, keyboard focus, skip link, reduced-motion support |
| Install | PWA (PC and Android), Docker, health check, env config |

Run the tests: `npm test` (backend: Phase 1, Phase 2, the promises audit and Chat Replay), `npm run test:responsive` (screen sizes) and `npm run test:e2e` (real browser with live video; needs `pip install playwright` and Chromium).

## Honest limits

1. **Video is peer-to-peer.** The streamer's device sends video to each viewer, so keep `MAX_VIEWERS_PER_STREAM` around 10-25. Bigger audiences need a media server (LiveKit). Quality selection and video replays are not possible until then (chat replay works today).
2. **One server only.** Live rooms are in memory. Scaling out needs the Socket.IO Redis adapter.
3. **Run a TURN server** (optional coturn service included) or some viewers on mobile data will not connect.
4. **Teen safety needs people.** The word filter is a starter. Before a public launch with minors you need real moderators, report review, a privacy policy, terms, and legal review (COPPA, GDPR-K and local rules). Parental consent is not included.
5. **Not built:** Circle polls and collaborative watch sessions, language and location preferences, friend connections, email (so password recovery uses admin-issued codes), and automatic content scanning. Posts and comments have a per-user cooldown and rate limit. See `docs/PROMISES_AUDIT.md` section E for what each missing piece needs.
6. **Profile pictures are the only uploads.** There is still no automatic image scanning, so for a public launch with minors have moderators check reported photos (the profile Report button covers them; Clear profile removes one) or add an image-scanning service first. Photo addresses (`/avatars/<id>.jpg`) can be opened without logging in. Post pictures and videos are covered by the safety note in the section above.
7. **Android app:** camera streaming works, screen sharing does not (platform limit).
8. **No email verification, password reset, payments or video recordings yet.** (Chat is recorded; video is not.)

## Steps: run it on your PC

1. Install Node.js 22.13 or newer (Node 24 works). No compiler or extra tools needed.
2. Open a terminal in this folder (the one with `package.json`) and run:
   ```
   npm install
   npm start
   ```
3. Open http://localhost:3000 in Chrome or Edge. A line saying SQLite is "experimental" is a harmless Node notice.
4. Try it with two windows (one normal, one private):
   - Window A: Sign up, **Go live**, **Use camera**, set a title, **Start stream**.
   - Window B: Sign up as another user and open the stream. You are **Early Bird #1**. Press **Pin**, send a question, send some reactions.
   - Window A: tap **Answered**, press **Poll** to run a poll, open **Dashboard**.

To install as an app: click the Install icon in the Chrome/Edge address bar.

## How people use NovaStream

**Everyone:** use **Feed** to post and react, **Circles** to find or start a community, the **bell** for alerts, and the search box for people, streams, Circles and posts. Click your avatar for your profile, badges and appreciation score.

**Viewer:** Browse and filter by category, open a stream, chat, react, vote in polls, follow. Hover a message for reactions, report, block, and (for mods) timeout/mute/delete. Edit your profile from your avatar. Manage blocked users in **Edit profile**.

**Early Bird:** the first 4 logged-in viewers each get 3 pins per stream. Press **Pin**, type, send. Max 4 pins show at once, the rest queue.

**Streamer:** **Go live** (camera or screen), add title, category, description and tags, **Start stream**. Stay on your channel page while live (leaving ends the stream). Use the **Streamer tools** bar for polls and slow mode. Appoint moderators and set blocked words in **Dashboard**.

## Put it online (production)

Streaming from phones needs **HTTPS**.

1. Get a small VPS and point a domain at it. Copy this folder there.
2. `cp .env.example .env`, then set `JWT_SECRET` (the command is in the file) and keep `EARLY_BIRD_MIN_ACCOUNT_AGE_MIN=60`.
3. `docker compose up -d --build`
4. Add HTTPS with Caddy (Caddyfile): `your-domain.com { reverse_proxy localhost:3000 }`
5. Recommended: set `TURN_URL`, `TURN_USER`, `TURN_PASS`, open ports 3478 and 49152-65535, then `docker compose --profile turn up -d`.
6. Check `https://your-domain.com/healthz` returns `{"ok":true}`.
7. Back up the `novastream-data` Docker volume (it holds the SQLite database).

## Install on Android

**Fastest:** open your HTTPS address in Chrome on the phone, menu, **Install app**. For quick testing from your PC use a tunnel: `cloudflared tunnel --url http://localhost:3000`.

**Native APK (Capacitor):** deploy first, then set `server.url` in `capacitor.config.json` to your domain, run
```
npm install --save-dev @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
```
add the CAMERA, RECORD_AUDIO and MODIFY_AUDIO_SETTINGS permissions to `android/app/src/main/AndroidManifest.xml`, then `npx cap sync android` and `npx cap open android` and build in Android Studio. Play Store needs a developer account, privacy policy, Data Safety form, and a read of the Families policy because the app serves teens.

## Settings (.env)

| Variable | Meaning | Default |
|---|---|---|
| `JWT_SECRET` | Signs logins. Required in production | none |
| `EARLY_BIRD_MIN_ACCOUNT_AGE_MIN` | Anti-bot account age for Early Birds | 0 |
| `MAX_VIEWERS_PER_STREAM` | Small-room cap | 25 |
| `BLOCKED_WORDS` | Site-wide masked words (channels add their own) | empty |
| `TURN_URL`, `TURN_USER`, `TURN_PASS` | TURN relay | none |
| `ADMIN_USERNAMES` | Comma-separated usernames that get the admin role | none |
| `BACKUP_EVERY_HOURS`, `BACKUP_KEEP` | Automatic backup schedule | 24, 7 |
| `CHAT_REPLAY`, `CHAT_REPLAY_DAYS` | Save chat for replays (`off` disables), and how many days to keep it | on, 30 |

The anti-bot account age, room size, post cooldown, sign-ups, maintenance mode and Chat Replay (on/off and days kept) are changed live in Admin, Site settings. The `.env` values are only the starting defaults.
| `POST_COOLDOWN_MS` | Minimum wait between a person's posts and comments | 3000 |
| `DB_PATH` | SQLite file | `data/novastream.db` |

Upgrading from the earlier "Huddle" version: your old data lives in `data/huddle.db`. Rename it to `novastream.db` (or set `DB_PATH`) to keep your accounts. The new columns are added automatically.

## Roadmap

- **Phase 2.5 (leftovers):** Circle polls and watch parties, image posts with upload scanning, language preferences, moderation console and appeals, creator verification.
- **Phase 3:** donations and memberships (needs a payment provider, company setup and legal review), clips and video replays (need a media server; chat replay is already done), scheduled events, multistreaming where other platforms' APIs allow it.

## Code map
`server.js` API, auth, chat, moderation, pins, polls, signaling. `social.js` feed, Circles, notifications, search, scores, analytics. `replay.js` Chat Replay (saving chat, playback API, retention). `public/replay.js` the replay page. `public/app.js` core front end and `public/social.js` Phase 2 pages. `tests/` backend and browser tests.
